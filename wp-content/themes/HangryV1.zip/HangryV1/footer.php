    </div>
    <footer class="site-footer">
        <div class="container">

        </div>
    </footer>

</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/skrollr/0.6.30/skrollr.min.js"></script>
<script type="text/javascript">
   var s = skrif(!(/Android|iPhone|iPad|iPod|BlackBerry|Windows Phone/i).test(navigator.userAgent || navigator.vendor || window.opera)){
    skrollr.init({
    forceHeight: false
    });
    }
</script>
<?php wp_footer(); ?>

</div>
</body>
</html>